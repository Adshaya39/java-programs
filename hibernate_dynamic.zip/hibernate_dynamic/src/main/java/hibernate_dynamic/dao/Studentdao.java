package hibernate_dynamic.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import hibernate_dynamic.dto.Student;


public class Studentdao {
	public EntityManager getEntityManager() {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("adshaya");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager;
	
	}
	public void savestudent(Student student) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
	
		student.setId(student.getId());
		student.setName(student.getName());
		student.setAddress(student.getAddress());
		
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
	}
	
	public void updatestudent(int id,String name,String address) {	
		EntityManager entityManager= getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Student student = entityManager.find(Student.class, id);
		student.setName(name);
		student.setAddress(address);
		entityTransaction.begin();
		entityManager.merge(student);
		entityTransaction.commit();		
	}
	
	public void deletestudent(int id) {
		EntityManager entityManager= getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Student student = entityManager.find(Student.class, id);
		entityTransaction.begin();
		entityManager.remove(student);
		entityTransaction.commit();			
		
	}
	public void getstudentbyid(int id) {
		EntityManager entityManager= getEntityManager();
		Student student = entityManager.find(Student.class, id);
		System.out.println(student);
	}
	public void getallstudent() {
		EntityManager entityManager= getEntityManager();
		Query query=entityManager.createQuery("Select S from student S");
		//List<Student>list=query.getResultList();
		//System.out.println(list);
		System.out.println(query.getResultList());
	}
	
}