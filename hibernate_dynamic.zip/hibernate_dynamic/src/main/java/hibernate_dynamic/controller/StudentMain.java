package hibernate_dynamic.controller;
import java.util.Scanner;

import hibernate_dynamic.dao.Studentdao;
import hibernate_dynamic.dto.Student;

public class StudentMain {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Student student=new Student();
		Studentdao studentdao=new Studentdao();
		boolean check=true;
		do {
			System.out.println("1. Save Student ");
			System.out.println("2. Update Student ");
			System.out.println("3. Delete Student ");
			System.out.println("4. Get Student by ID ");
			System.out.println("5. Get All Student ");
			int choice=scanner.nextInt();
			
			switch (choice) {
			case 1:{
				System.out.println("Enter the Id : ");
				int id=scanner.nextInt();
				System.out.println("Enter the Name : ");
				String name=scanner.next();
				System.out.println("Enter the Address : ");
				String address=scanner.next();
				
				student.setId(id);
				student.setName(name);
				student.setAddress(address);
				
				studentdao.savestudent(student);
			}
			break;
			
			case 2:{
				System.out.println("Enter the Id : ");
				int id=scanner.nextInt();
				System.out.println("Enter the Name : ");
				String name=scanner.next();
				System.out.println("Enter the Address : ");
				String address=scanner.next();
				
				student.setId(id);
				student.setName(name);
				student.setAddress(address);
				
				studentdao.updatestudent(id, name, address);
			}
			break;
			
			case 3:{
				System.out.println("Enter the Id : ");
				int id=scanner.nextInt();
				student.setId(id);
				studentdao.deletestudent(id);
			}
			break;
			case 4:{
				System.out.println("Enter the Id : ");
				int id=scanner.nextInt();
				student.setId(id);
				studentdao.getstudentbyid(id);
			}
			break;
			case 5:{
				studentdao.getallstudent();
			}
			break;

			default:
				break;
			}
		
		}while(check);
	}
}
