package com.jsp.springboot_item;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootItemApplication.class, args);
	}

}
