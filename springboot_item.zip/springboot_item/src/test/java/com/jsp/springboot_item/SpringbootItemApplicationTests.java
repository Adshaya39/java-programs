package com.jsp.springboot_item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
