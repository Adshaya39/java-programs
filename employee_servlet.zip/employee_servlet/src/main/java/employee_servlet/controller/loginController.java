package employee_servlet.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import employee_servlet.dao.Employeedao;
import employee_servlet.dto.Employee;

@WebServlet("/login")
public class loginController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		

		 Employeedao employeedao=new Employeedao();
		 Employee employee=employeedao.loginEmployee(email, password);
		 if(employee!=null) {
			 resp.sendRedirect("https://www.google.com/chrome/?brand=VDKB&ds_kid=43700053271226624&gclid=dc0e1cb6472c13dc6150784a774ed131&gclsrc=3p.ds&&utm_source=bing&utm_medium=cpc&utm_campaign=1605158%20%7C%20Chrome%20Win11%20%7C%20DR%20%7C%20ESS01%20%7C%20APAC%20%7C%20IN%20%7C%20en%20%7C%20Desk%20%7C%20SEM%20%7C%20BKWS%20-%20EXA%20%7C%20Txt%20%7C%20Bing_Top%20KWDS&utm_term=google%20chrome&utm_content=Desk%20%7C%20BKWS%20-%20EXA%20%7C%20Txt_Google%20Chrome_Top%20KWDS&gclid=dc0e1cb6472c13dc6150784a774ed131&gclsrc=3p.ds");
		 }else {
			 RequestDispatcher dispatcher=req.getRequestDispatcher("login.html");
			 dispatcher.include(req, resp);
		 }
		 
		
	}
}
