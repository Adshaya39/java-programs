package springmvc_employee.config;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "springmvc_employee")
public class Employeeconfig {
	@Bean// to tell ioc container to create 3rd party objects
	public EntityManager getEntityManager() {
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("adshaya");
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		return entityManager;
	}

}
