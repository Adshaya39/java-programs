package user_properties;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class UserMain {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter ID : ");
		int id=scanner.nextInt();
		System.out.println("Enter UserName : ");
		String username=scanner.next();
		System.out.println("Enter Email : ");
		String email=scanner.next();
		System.out.println("Enter Password : ");
		String password=scanner.next();
		
		User user=new User();
		user.setId(id);
		user.setUsername(username);
		user.setEmail(email);
		user.setPassword(password);
		
		UserCrud curd=new UserCrud();
		try {
			curd.signupuser(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}
}
