package user_properties;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import com.mysql.cj.jdbc.Driver;

public class UserCrud {
	//crud operations -- create read update delete	
	
	public Connection getConnection() throws SQLException, IOException {
		Driver driver=new Driver();
		DriverManager.registerDriver(driver);
		FileInputStream fileInputStream = new FileInputStream("config.properties");
		Properties properties = new Properties();
		properties.load(fileInputStream);
		Connection connection=DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"),properties.getProperty("password"));
		return connection;		
	}
	public User signupuser(User user) throws SQLException, IOException {
		Connection connection = getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement("Insert into user values(?,?,?,?)");
		preparedStatement.setInt(1, user.getId());
		preparedStatement.setString(2, user.getUsername());
		preparedStatement.setString(3, user.getEmail());
		preparedStatement.setString(4, user.getPassword());
		preparedStatement.execute();
		connection.close();
		System.out.println("Inserted...");
		return user;
		
	}
}
