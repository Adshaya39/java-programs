package jdbc_tsk1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Delete {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.LOAD OR REGISTER THE DRIVER
		Class.forName("com.mysql.cj.jdbc.Driver");
				
		//2.Establish connection
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/task1_jdbc", "root", "T#9758@qlph");
				
		//3.Create Statement
		Statement statement = connection.createStatement();
				
		//4.Execute Statement
		statement.execute("delete from student where id=4");
		
		//5.Close connection
		connection.close();
		
		System.out.println("Deleted...");
				
	}
}
