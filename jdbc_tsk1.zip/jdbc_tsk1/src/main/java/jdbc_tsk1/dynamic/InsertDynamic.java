package jdbc_tsk1.dynamic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertDynamic {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Number of rows : ");
		int n =scanner.nextInt();
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/dynamic_student", "root", "T#9758@qlph");
		
		for(int i=0;i<n;i++) {
			System.out.println("Enter the ID : ");
			int id =scanner.nextInt();
			System.out.println("Enter the Name : ");
			String studentname =scanner.next();
			System.out.println("Enter the Marks : ");
			long marks=scanner.nextLong();		
			PreparedStatement preparedStatement=connection.prepareStatement("insert into student values(?,?,?)");
			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, studentname);
			preparedStatement.setLong(3, marks);
			preparedStatement.execute();
			
		}
		connection.close();
		System.out.println("Inserted....");
	}
}
