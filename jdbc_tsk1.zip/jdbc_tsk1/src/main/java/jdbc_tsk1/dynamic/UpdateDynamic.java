package jdbc_tsk1.dynamic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDynamic {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Which has to be updated : ");
		System.out.println("Enter the ID : ");
		int id =scanner.nextInt();
		System.out.println("What has to update name(1) mark(2) both(3) ");
		int i =scanner.nextInt();
		int count = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/dynamic_student", "root", "T#9758@qlph");
		switch(i) {
		case 1:{
			System.out.println("Enter the Name : ");
			String studentname =scanner.next();
			PreparedStatement preparedStatement = connection.prepareStatement("update student set studentname = ? WHERE id = ?");
			preparedStatement.setString(1, studentname);
			preparedStatement.setInt(2, id);
			count = preparedStatement.executeUpdate();
			break;
		}
		
		case 2: {
			System.out.println("Enter the Marks : ");
			long marks=scanner.nextLong();
			PreparedStatement preparedStatement = connection.prepareStatement("update student set mark = ? WHERE id = ?");
			preparedStatement.setLong(1, marks);
			preparedStatement.setInt(2, id);
			count = preparedStatement.executeUpdate();
			break;
		}
		
		case 3: { 
			System.out.println("Enter the Name : ");
			String studentname =scanner.next();
			System.out.println("Enter the Marks : ");
			long marks=scanner.nextLong();
			PreparedStatement preparedStatement= connection.prepareStatement("update student set studentname = ? , mark = ? WHERE id = ?");
			preparedStatement.setString(1, studentname);
			preparedStatement.setLong(1, marks);
			preparedStatement.setInt(2, id);
			count = preparedStatement.executeUpdate();
			break;
		}
	}
		

	connection.close();
	System.out.println(count+" rows got affected.");

	}
}
