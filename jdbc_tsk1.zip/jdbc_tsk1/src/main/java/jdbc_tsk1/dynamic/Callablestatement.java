package jdbc_tsk1.dynamic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.CallableStatement;

public class Callablestatement {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");//load Driver
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcallable", "root", "T#9758@qlph");//Establish Connection
		
		//CallableStatement callableStatement=connection.prepareCall("call dbcallable.saveitem(2, 'denim', 4000)");//Create Statement
		//callableStatement.execute();//execute statement 
		
		CallableStatement callableStatement=connection.prepareCall("call dbcallable.fetchitem()");
		ResultSet resultSet=callableStatement.executeQuery();
		while(resultSet.next()) {
			System.out.println(resultSet.getInt(1)+" : "+resultSet.getString(2)+" : "+resultSet.getInt(3));
		}
		connection.close(); //close connection
		//System.out.println("Inserted...");
	}
}
