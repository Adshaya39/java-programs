package jdbc_tsk1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Update {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.LOAD OR REGISTER THE DRIVER
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//2.Estabish connection
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/task1_jdbc", "root", "T#9758@qlph");
		
		//3.Create Statement
		Statement statement = connection.createStatement();
		
		//4.Execute Statement
		int count = statement.executeUpdate("UPDATE student SET studentname = 'Ayadsha' WHERE id = 1");
		
		//5.close
		connection.close();
	
		System.out.println(count);
	
	}
}
