package jdbc_tsk1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

//import com.mysql.cj.jdbc.BlobFromLocator;

public class Insert {
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		//1.LOAD OR REGISTER THE DRIVER
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//2.Establish connection
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/task1_jdbc", "root", "T#9758@qlph");
		
		//3.create Statement
		Statement statement=connection.createStatement();
		
		//4.Execute Statement
		statement.execute("Insert into student value('3','Rabin',100),('4','Raya',99)");
		
		//5.close
		connection.close();
		
		System.out.println("Inserted");
	}
}
