/*package product_servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product_servlet.dao.Productdao;
import product_servlet.dto.Product;

public class ProductServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("name");
		String brand=req.getParameter("brand");
		double price=Double.parseDouble(req.getParameter("price"));
		String manufacture=req.getParameter("manufacture");
		String state=req.getParameter("state");
		
		ServletContext context=getServletContext();
		double cgst=Double.parseDouble(context.getInitParameter("cgst"));
		
		ServletConfig config=getServletConfig();
		double kar=Double.parseDouble(context.getInitParameter("kar"));
		double tn=Double.parseDouble(context.getInitParameter("tn"));
		
		Product product=new Product();
		PrintWriter printWriter=resp.getWriter();
		if(state.equals("kar")) {
			price+=(cgst+kar)*price;
			product.setPrice(price);
			printWriter.print(price);
		}else if(state.equals("tn")) {
			price+=(cgst+tn)*price;
			product.setPrice(price);
			printWriter.print(price);
		}
		product.setName(name);
		product.setBrand(brand);
		product.setManufacture(manufacture);
		product.setState(state);
		
		Productdao productdao=new Productdao();
		productdao.saveProduct(product);
		
	}

}*/



package product_servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product_servlet.dao.Productdao;
import product_servlet.dto.Product;

public class ProductServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("name");
		String brand=req.getParameter("brand");
		double price=Double.parseDouble(req.getParameter("price"));
		String manufacture=req.getParameter("manufacture");
		String state=req.getParameter("state");
		
		ServletContext context=getServletContext();
		double cgst=Double.parseDouble(context.getInitParameter("cgst"));
		
		ServletConfig config=getServletConfig();
		double kar=Double.parseDouble(config.getInitParameter("kar")) ;
		double tn=Double.parseDouble(config.getInitParameter("tn")) ;
		
		Product product=new Product();
		PrintWriter printWriter=resp.getWriter();
		if(state.equals("kar")) {
			price+=(cgst+kar)*price;
			product.setPrice(price);
			printWriter.print(price);
		}else if(state.equals("tn")) {
			price+=(cgst+tn)*price;
			product.setPrice(price);
			printWriter.print(price);
		}
		product.setName(name);
		product.setBrand(brand);
		product.setManufacture(manufacture);
		product.setState(state);
		
		Productdao productdao=new Productdao();
		productdao.saveProduct(product);
	}
}
