package com.jsp.Springboot_HospitalManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootHospitalManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHospitalManagementSystemApplication.class, args);
	}

}
