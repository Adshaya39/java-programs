package com.jsp.Springboot_HospitalManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHospitalManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
